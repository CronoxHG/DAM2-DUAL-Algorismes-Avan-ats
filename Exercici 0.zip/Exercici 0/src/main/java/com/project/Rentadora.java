package com.project;

public class Rentadora extends Electrodomestic {
    public int revolucions;
    public int soroll;

    public Rentadora() {}

    public Rentadora(Rentadora target) {
        super(target); 
        if (target != null) {
            this.revolucions = target.revolucions;
            this.soroll = target.soroll;
        }
    }

    @Override
    public Rentadora clone() {
        return new Rentadora(this); 
    }

    @Override
    public boolean equals(Object object2) {
        if (this == object2) return true;
        if (!(object2 instanceof Rentadora) || !super.equals(object2)) return false;
        Rentadora rentadora = (Rentadora) object2;
        return rentadora.revolucions == revolucions && rentadora.soroll == soroll;
    }

    @Override
public String toString() {
    return super.toString() + ", Revolucions: " + revolucions + ", Soroll: " + soroll;
}


}
