package com.project;

public class Forn extends Electrodomestic {
    public int temperatura;
    public boolean autoneteja;

    public Forn() {}

    public Forn(Forn target) {
        super(target); 
        if (target != null) {
            this.temperatura = target.temperatura;
            this.autoneteja = target.autoneteja;
        }
    }

    @Override
    public Forn clone() {
        return new Forn(this); 
    }

    @Override
    public boolean equals(Object object2) {
        if (this == object2) return true;
        if (!(object2 instanceof Forn) || !super.equals(object2)) return false;
        Forn forn = (Forn) object2;
        return forn.temperatura == temperatura && forn.autoneteja == autoneteja;
    }

    @Override
public String toString() {
    return super.toString() + ", Temperatura: " + temperatura + ", Autoneteja: " + autoneteja;
}

}
