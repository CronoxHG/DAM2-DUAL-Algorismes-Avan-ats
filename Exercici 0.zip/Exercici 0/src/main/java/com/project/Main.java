package com.project;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        
        List<Electrodomestic> llista = new ArrayList<>();
        List<Electrodomestic> llistaCopy = new ArrayList<>();

    
        Rentadora rentadora = new Rentadora();
        rentadora.nom = "Rentadora1";
        rentadora.color = "Blanca";
        rentadora.preu = 500.0;
        rentadora.marca = "Bosch";
        rentadora.eficiència = "A++";
        rentadora.revolucions = 1200;
        rentadora.soroll = 60;
        llista.add(rentadora);

     
        Rentadora rentadoraClone = (Rentadora) rentadora.clone();
        llistaCopy.add(rentadoraClone);

        
        Nevera nevera = new Nevera();
        nevera.nom = "Nevera1";
        nevera.color = "Negra";
        nevera.preu = 800.0;
        nevera.marca = "Samsung";
        nevera.eficiència = "A+";
        nevera.frigories = 3000;
        nevera.soroll = 40;
        llista.add(nevera);
        llistaCopy.add((Nevera) nevera.clone()); 

        Forn forn = new Forn();
        forn.nom = "Forn1";
        forn.color = "Inox";
        forn.preu = 350.0;
        forn.marca = "Balay";
        forn.eficiència = "A";
        forn.temperatura = 250;
        forn.autoneteja = true;
        llista.add(forn);
        llistaCopy.add((Forn) forn.clone()); 

        System.out.println("Comparar la llista amb ella mateixa:");
        for (int i = 0; i < llista.size(); i++) {
            compareSelf(i, llista.get(i));
        }

        
        System.out.println("\nComparar la llista amb els clons:");
        for (int i = 0; i < llista.size(); i++) {
            compareClone(i, llista.get(i), llistaCopy.get(i));
        }
    }

    
    static void compareSelf(int i, Electrodomestic obj) {
        if (obj == obj) {
            System.out.println(i + ": Els electrodomèstics són el mateix objecte");
        }
        System.out.println(i + ": Classe: " + obj.getClass().getSimpleName());
        System.out.println(i + ": Dades: " + obj.toString()); 
    }

    
    static void compareClone(int i, Electrodomestic original, Electrodomestic clone) {
        if (original != clone) {
            System.out.print(i + ": Els electrodomèstics són objectes diferents - ");
            if (original.getClass() == clone.getClass() && original.equals(clone)) {
                System.out.println("Són de la mateixa classe i tenen iguals dades");
            } else {
                System.out.println("No són de la mateixa classe o no tenen iguals dades");
            }
        }
    }
}
