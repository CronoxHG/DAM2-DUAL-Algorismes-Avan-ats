package com.project;

public class Nevera extends Electrodomestic {
    public int frigories;
    public int soroll;

    public Nevera() {}

    public Nevera(Nevera target) {
        super(target); 
        if (target != null) {
            this.frigories = target.frigories;
            this.soroll = target.soroll;
        }
    }

    @Override
    public Nevera clone() {
        return new Nevera(this); 
    }

    @Override
    public boolean equals(Object object2) {
        if (this == object2) return true;
        if (!(object2 instanceof Nevera) || !super.equals(object2)) return false;
        Nevera nevera = (Nevera) object2;
        return nevera.frigories == frigories && nevera.soroll == soroll;
    }

    @Override
public String toString() {
    return super.toString() + ", Frigories: " + frigories + ", Soroll: " + soroll;
}

}

