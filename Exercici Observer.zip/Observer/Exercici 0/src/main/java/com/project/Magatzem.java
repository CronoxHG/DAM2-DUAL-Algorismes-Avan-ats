package com.project;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;

public class Magatzem {
    private ArrayList<Producte> productes;
    public int capacitat;
    private PropertyChangeSupport support;
    private Entregues entregues;  

    public Magatzem(Entregues entregues) {
        this.productes = new ArrayList<>();
        this.capacitat = 10;
        this.support = new PropertyChangeSupport(this);
        this.entregues = entregues;  
    }

    public ArrayList<Producte> getProductes() {
        return productes;
    }

    public void addProducte(Producte producte) {
        if (productes.size() < capacitat) {
            productes.add(producte);
            capacitat--;
            support.firePropertyChange("magatzemAdd", null, producte);
        } else {
            System.out.println("El magatzem és ple!");
        }
    }

    public void removeProducte(int id) {
        Producte producteARemoure = null;
        for (Producte producte : productes) {
            if (producte.getId() == id) {
                producteARemoure = producte;
                
                break;
            }
        }
        if (producteARemoure != null) {
            productes.remove(producteARemoure);
            capacitat++;
            support.firePropertyChange("magatzemRemove", producteARemoure, null);
            
            
            entregues.addProducte(producteARemoure);  
            support.firePropertyChange("magatzemEntrega", null, producteARemoure);  // Notificar moviment a entregues
        }
    }

    public Entregues entregues() {
        return entregues;
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        support.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        support.removePropertyChangeListener(listener);
    }

    @Override
    public String toString() {
        return "Magatzem{" +
                "productes=" + productes +
                ", capacitat=" + capacitat +
                '}';
    }
}
