package com.project;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class Main {
    public static void main(String[] args) {
        Producte p0 = new Producte(0, "Llibre");
        Producte p1 = new Producte(1, "Boli");
        Producte p2 = new Producte(2, "Rotulador");
        Producte p3 = new Producte(3, "Carpeta");
        Producte p4 = new Producte(4, "Motxilla");

        Entregues entregues = new Entregues();
        Magatzem magatzem = new Magatzem(entregues); 
 
        // Aquí afegir els property listeners adequats
        PropertyChangeListener listener = new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                switch (evt.getPropertyName()) {
                    case "producteId":
                        System.out.println("Producte ha canviat l'id de '" + evt.getOldValue() + "' a '" + evt.getNewValue() + "'");
                        break;
                    case "producteName":
                        System.out.println("Producte ha canviat el nom de '" + evt.getOldValue() + "' a '" + evt.getNewValue() + "'");
                        break;
                    case "magatzemAdd":
                        System.out.println("S'ha afegit el producte amb id " + ((Producte) evt.getNewValue()).getId() + " al magatzem, capacitat: " + magatzem.capacitat);
                        break;
                    case "magatzemRemove":
                        System.out.println("S'ha esborrat el producte amb id " + ((Producte) evt.getOldValue()).getId() + " del magatzem, capacitat: " + magatzem.capacitat);
                        break;
                    case "magatzemEntrega":
                        System.out.println("S'ha mogut el producte amb id " + ((Producte) evt.getNewValue()).getId() + " del magatzem cap a les entregues");
                        break;
                    case "entreguesAdd":
                        System.out.println("S'ha afegit el producte amb id " + ((Producte) evt.getNewValue()).getId() + " a la llista d'entregues");
                        break;
                    case "entreguesRemove":
                        System.out.println("S'ha entregat el producte amb id " + ((Producte) evt.getOldValue()).getId());
                        break;
                }
            }
        };

        p0.addPropertyChangeListener(listener);
        p1.addPropertyChangeListener(listener);
        p2.addPropertyChangeListener(listener);
        p3.addPropertyChangeListener(listener);
        p4.addPropertyChangeListener(listener);


        magatzem.addPropertyChangeListener(listener);
        entregues.addPropertyChangeListener(listener);


        p0.setId(5);
        p0.setNom("Llibreta");
        p1.setNom("Boli");
 
        magatzem.addProducte(p0);
        magatzem.addProducte(p1);
        magatzem.addProducte(p2);
        magatzem.addProducte(p3);
        magatzem.addProducte(p4);
 
        magatzem.removeProducte(2);
        magatzem.removeProducte(3);
        magatzem.removeProducte(4);
 
        entregues.removeProducte(2);
        entregues.removeProducte(3);
 
        System.out.println(magatzem);
        System.out.println(entregues);
    }
 }