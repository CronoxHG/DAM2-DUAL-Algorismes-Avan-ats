package com.project;

import java.lang.reflect.Constructor;

public class Main {

    public static void main(String[] args) {
        for (int i = 0; i <= 2; i++) {
            System.out.println("Iniciant: " + i);
            
            
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                System.out.println("Error al intentar hacer la pausa.");
                Thread.currentThread().interrupt();  
            }
        }

        Object manel = Object.getInstance("Manel", "Polar", 18);
        

        System.out.println(manel);
        System.out.println(manel);
        System.out.println(manel);

    }

    


    
}