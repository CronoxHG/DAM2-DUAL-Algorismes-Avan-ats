package com.project;

public class Main {

    public static void main(String[] args) {
        try {
        
            for (int i = 0; i < 3; i++) {
                System.out.println("Iniciant: " + i);
                
                Thread.sleep(3000);
            }

            
            String[] noms = {"Pablo", "Arnau", "Wade"};
            String[] cognoms = {"Casas", "Perez", "Wilson"};
            int[] edats = {30, 25, 35};  

            for (int i = 0; i < 3; i++) {
                
                Object inst = Object.getNewDestroyedInstance(noms[i], cognoms[i], edats[i]);

                
                System.out.println(inst);
            }

        } catch (InterruptedException e) {
            System.out.println("Error al intentar hacer la pausa.");
            Thread.currentThread().interrupt();  
        }
    }
}

