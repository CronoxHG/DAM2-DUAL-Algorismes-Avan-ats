package com.project;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Object {

    
    private static Object instance;

    
    private String nom;
    private String cognom;
    private int edat;

   
    private Object(String nom, String cognom, int edat) {
        this.nom = nom;
        this.cognom = cognom;
        this.edat = edat;
    }

   
    public static Object getInstance(String nom, String cognom, int edat) {
        if (instance == null) {
            instance = new Object(nom, cognom, edat);
        }
        return instance;
    }

   
    public static Object getNewDestroyedInstance(String nom, String cognom, int edat) {
        try {
          
            Constructor<Object> constructor = Object.class.getDeclaredConstructor(String.class, String.class, int.class);
            constructor.setAccessible(true); 

            
            return constructor.newInstance(nom, cognom, edat);

        } catch (NoSuchMethodException | IllegalAccessException | InstantiationException | InvocationTargetException e) {
            e.printStackTrace();
        }
        return null; 
    }

   
    @Override
    public String toString() {
        return "Nom: " + nom + ", Cognom: " + cognom + ", Edat: " + edat;
    }
}


